import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_BASE_URL, absoluteUrl } from '../config/api';

// Per-account, per-section/subject/date cache of the last successfully
// fetched roster, so a teacher who opens a roster (or the Scan screen, which
// also needs this to resolve a scanned code to a student) offline still sees
// real data instead of an error - same cache-then-network pattern as
// academicScheduleService.ts's fetchMySchedule.
const ROSTER_CACHE_PREFIX = '@attendance_roster_cache_v1';

function rosterCacheKey(token: string, sectionId: number, subjectId: number, date: string): string {
  return `${ROSTER_CACHE_PREFIX}:${token.slice(-12)}:${sectionId}:${subjectId}:${date}`;
}

// --- Shared fetch helper (same pattern as teacherClassService.ts) ---

function firstErrorMessage(data: any): string | null {
  if (!data) return null;
  if (typeof data.message === 'string') return data.message;
  if (typeof data.error === 'string') return data.error;
  if (data.errors && typeof data.errors === 'object') {
    const first = Object.values(data.errors)[0];
    if (Array.isArray(first) && typeof first[0] === 'string') return first[0];
  }
  return null;
}

async function authedPost(path: string, token: string, body: Record<string, any> = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(body),
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(firstErrorMessage(data) ?? `Request failed (${response.status})`);
  }

  return data;
}

// --- Constants (must match Attendance::STATUSES / HOMEROOM_SUBJECT_ID on the backend) ---

export const HOMEROOM_SUBJECT_ID = 0;

// Widened from a fixed 5-value union to a plain string: attendance statuses
// are now school-configurable (see AttendanceStatusConfig /
// fetchTeacherAttendanceStatuses below), so a status "code" is whatever the
// admin configured, not necessarily one of the original 5. The 5 defaults
// below remain the fallback for a school that hasn't configured any yet
// (both server- and client-side).
export type AttendanceStatus = string;

export const ATTENDANCE_STATUSES: AttendanceStatus[] = ['present', 'late', 'absent', 'excused', 'leave'];

// --- Types ---

export interface AttendanceClassOption {
  section_id: number;
  section_name: string;
  class_id: number;
  class_name: string | null;
  subject_id: number;
  subject_name: string | null;
  role: 'homeroom' | 'subject';
  day_of_week?: string | null;
  start_time?: string | null;
  end_time?: string | null;
}

export interface RosterStudent {
  student_id: number;
  student_name: string;
  // Present once the backend fix that adds it to teacher_attendance_roster
  // is deployed; optional so this keeps working against an older backend.
  code?: string | null;
  photo: string | null;
  // Optional - only present once the backend includes user_information's
  // address/gender/birthday (decoded into a precomputed age) in the roster
  // response. Missing on an older backend just means the big attendance
  // card falls back to showing name/photo/status only.
  address?: string | null;
  gender?: string | null;
  age?: number | null;
  status: AttendanceStatus | null;
  check_in_time: string | null;
  remarks: string | null;
  attendance_id: number | null;
}

export interface AttendanceSummary {
  [status: string]: number;
}

export interface AttendanceRoster {
  section_id: number;
  section_name: string;
  subject_id: number;
  date: string;
  students: RosterStudent[];
  summary: AttendanceSummary;
  // Once a teacher submits this section/subject/date ("done"), it locks -
  // no more edits/resubmits until an admin unlocks it. Optional so this
  // keeps working against an older backend that doesn't send lock state yet.
  locked?: boolean;
  locked_at?: string | null;
  locked_by_name?: string | null;
}

export interface AttendanceRecordInput {
  student_id: number;
  status: AttendanceStatus;
  check_in_time?: string | null;
  remarks?: string | null;
}

export interface HistoryRecord {
  id: number;
  student_id: number;
  subject_id: number;
  date: string;
  status: AttendanceStatus;
  check_in_time: string | null;
  remarks: string | null;
}

export interface DynamicAttendanceStatus {
  id: number;
  code: string;
  label: string;
  color: string | null;
  counts_as_present: boolean;
  requires_remark: boolean;
  sort_order: number;
}

/**
 * The school's admin-configured attendance statuses (see AttendanceConfigScreen),
 * read via a teacher-reachable route since admin_attendance_status_list is
 * admin-only. Falls back to the same 5 hardcoded defaults server-side for a
 * school that hasn't configured any yet, so this always returns a usable list.
 */
export async function fetchTeacherAttendanceStatuses(token: string): Promise<DynamicAttendanceStatus[]> {
  const data = await authedPost('/teacher_attendance_statuses', token);
  return data.statuses ?? [];
}

// --- Teacher: which classes/subjects they can take attendance for ---

export async function fetchAttendanceClasses(token: string): Promise<AttendanceClassOption[]> {
  const data = await authedPost('/teacher_attendance_classes', token);
  return data.classes ?? [];
}

// --- Teacher: roster for one section/subject/date ---

export async function fetchAttendanceRoster(
  token: string,
  sectionId: number,
  subjectId: number,
  date: string
): Promise<AttendanceRoster> {
  const cacheKey = rosterCacheKey(token, sectionId, subjectId, date);
  try {
    const data = await authedPost('/teacher_attendance_roster', token, {
      section_id: sectionId,
      subject_id: subjectId,
      date,
    });
    const students: any[] = data.students ?? [];
    const roster: AttendanceRoster = {
      section_id: data.section_id,
      section_name: data.section_name,
      subject_id: data.subject_id,
      date: data.date,
      summary: data.summary ?? {},
      students: students.map((s) => ({
        ...s,
        photo: absoluteUrl(s.photo ?? null),
      })),
      locked: !!data.locked,
      locked_at: data.locked_at ?? null,
      locked_by_name: data.locked_by_name ?? null,
    };
    AsyncStorage.setItem(cacheKey, JSON.stringify(roster)).catch(() => {
      // Best-effort cache write - losing it just means a future offline
      // load falls back further (or throws), not that this call fails.
    });
    return roster;
  } catch (err) {
    try {
      const cached = await AsyncStorage.getItem(cacheKey);
      if (cached) return JSON.parse(cached) as AttendanceRoster;
    } catch {
      // Fall through to rethrow the original network error.
    }
    throw err;
  }
}

// --- Teacher: save/overwrite a batch of statuses for a section/subject/date ---

export async function submitAttendance(
  token: string,
  sectionId: number,
  subjectId: number,
  date: string,
  records: AttendanceRecordInput[]
): Promise<{ message: string; summary: AttendanceSummary; count: number; locked?: boolean; locked_at?: string | null }> {
  return authedPost('/teacher_attendance_submit', token, {
    section_id: sectionId,
    subject_id: subjectId,
    date,
    records,
  });
}

/**
 * Optimistically applies a set of records to the cached roster (written by
 * fetchAttendanceRoster above) and re-persists it, so a Save made while
 * offline - queued via enqueueAttendanceSubmit rather than actually sent -
 * still shows up immediately if the teacher reopens this roster before the
 * queue has a chance to flush. Returns null if there's nothing cached yet
 * for this roster (nothing to update).
 */
export async function applyRecordsToCachedRoster(
  token: string,
  sectionId: number,
  subjectId: number,
  date: string,
  records: AttendanceRecordInput[],
): Promise<AttendanceRoster | null> {
  const cacheKey = rosterCacheKey(token, sectionId, subjectId, date);
  try {
    const cached = await AsyncStorage.getItem(cacheKey);
    if (!cached) return null;
    const roster = JSON.parse(cached) as AttendanceRoster;
    const byId = new Map(records.map((r) => [r.student_id, r]));
    const students = roster.students.map((s) => {
      const rec = byId.get(s.student_id);
      if (!rec) return s;
      return { ...s, status: rec.status, check_in_time: rec.check_in_time ?? s.check_in_time, remarks: rec.remarks ?? s.remarks };
    });
    const summary: AttendanceSummary = {};
    for (const s of students) {
      if (s.status) summary[s.status] = (summary[s.status] ?? 0) + 1;
    }
    const updated: AttendanceRoster = { ...roster, students, summary };
    await AsyncStorage.setItem(cacheKey, JSON.stringify(updated));
    return updated;
  } catch {
    return null;
  }
}

// --- Teacher: one-scan check-in via a student's QR/ID code ---

export interface ScanResult {
  message: string;
  student: RosterStudent;
  summary: AttendanceSummary;
}

export async function scanAttendance(
  token: string,
  sectionId: number,
  subjectId: number,
  date: string,
  code: string
): Promise<ScanResult> {
  const data = await authedPost('/teacher_attendance_scan', token, {
    section_id: sectionId,
    subject_id: subjectId,
    date,
    code,
  });
  return {
    message: data.message,
    student: { ...data.student, photo: absoluteUrl(data.student?.photo ?? null) },
    summary: data.summary ?? {},
  };
}

// --- Teacher: edit a single already-submitted record (blocked once the school's edit window has passed) ---

export async function updateAttendanceRecord(
  token: string,
  attendanceId: number,
  status: AttendanceStatus,
  reason?: string | null
): Promise<{ message: string; attendance: any }> {
  return authedPost('/teacher_attendance_update', token, {
    attendance_id: attendanceId,
    status,
    reason: reason ?? null,
  });
}

// --- Teacher: date-range history for one section/subject ---

export async function fetchAttendanceHistory(
  token: string,
  sectionId: number,
  subjectId: number | null,
  dateFrom: string,
  dateTo: string
): Promise<HistoryRecord[]> {
  const data = await authedPost('/teacher_attendance_history', token, {
    section_id: sectionId,
    subject_id: subjectId,
    date_from: dateFrom,
    date_to: dateTo,
  });
  return data.records ?? [];
}
